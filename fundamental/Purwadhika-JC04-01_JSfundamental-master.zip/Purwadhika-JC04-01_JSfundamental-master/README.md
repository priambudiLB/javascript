# Purwadhika JavaScript Fundamental

![Lintang_Purwadhika](https://static.wixstatic.com/media/2e6af2_f69a4271c3534ae1869a7ed63e278b2b~mv2.png/v1/fill/w_246,h_39,al_c,usm_0.66_1.00_0.01/2e6af2_f69a4271c3534ae1869a7ed63e278b2b~mv2.png)

### Materi Job Connector Purwadhika Batch 04 (Jan-Apr 2018)

No.|Modul|Unduh
-----|-----|-----
1.|JavaScript Fundamental|*[bit.ly/jc04fundamental](https://github.com/LintangWisesa/Purwadhika-01-JS_Fundamental)*
2.|Front-End Development|*[bit.ly/jc04frontend](https://github.com/LintangWisesa/Purwadhika-JC04-02_FrontEndWeb)*
3.|Back-End Development|*[bit.ly/jc04backend](https://github.com/LintangWisesa/Purwadhika-JC04-03_BackEndWeb)*
4.|Mobile Development|*[bit.ly/jc04mobile](https://github.com/LintangWisesa/Purwadhika-JC04-04_Mobile)*

### Modul 1 JavaScript Fundamental:

- Intro to JavaScript
- String & Number
- Basic HTML
- Logic, If & Switch
- Loop
- Function & Array
- HTML & JavaScript
- Object
- JavaScript ES6
- Data Structures
- Algorithms
