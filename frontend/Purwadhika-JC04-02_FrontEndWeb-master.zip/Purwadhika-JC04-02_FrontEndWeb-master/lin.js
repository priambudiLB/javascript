let alaskaki = 'sepatu';
let warna = 'merah';

if(alaskaki == 'sepatu' && warna == 'merah'){
    console.log('Saya suka sepatu merah.');
};

if(alaskaki == 'sepatu' && warna == 'merah'){
    console.log('Saya suka sepatu merah.');
};

